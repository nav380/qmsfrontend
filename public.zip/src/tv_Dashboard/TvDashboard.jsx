// import { useState, useEffect } from "react"
// import TvDashboard1 from "./TvDashboard1";
// import TvDashboard2 from "./TvDashboard2";



// const TvDashboard = () => {
//     const [tvdisplay, setTvDisplay] = useState('tvone')

//         useEffect(() => { 
//         let displaychange; 

//         // initial switching condition
//         if (tvdisplay === 'tvone') {
//             displaychange = setInterval(() => {
//                 setTvDisplay('tvtwo')
//             }, 10000);   //1000 = 1s
//         }
//         // dishplay switching second condition
//         else if (tvdisplay === "tvtwo") {
//             displaychange = setInterval(() => {
//                 setTvDisplay('tvone')
//             }, 10000);  // 15000 = 15s
//         }
//     return ()=> clearInterval(displaychange)
//     }, [tvdisplay]);
    
//     return (
//         <>
//             {(tvdisplay === 'tvone') ? (<TvDashboard1 />) : (<TvDashboard2 />)}
//         </>
//     )
// }
// export default TvDashboard;


import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import TvDashboard1 from "./TvDashboard1";
import TvDashboard2 from "./TvDashboard2";
import TvDashboard3 from "./TvDashboard3";

const TvDashboard = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { line_id } = useParams();
  const {process_id} = useParams();
  const {section_id} = useParams();
  console.log('Line ID in TvDashboard:', line_id);

  const dashboards = [<TvDashboard1 />, <TvDashboard2 line_id={line_id} />, <TvDashboard3 />];

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
    }, 20000); // 10 seconds

    return () => clearInterval(intervalId);
  }, []);

  return (
    <>
      {dashboards[currentIndex]}
    </>
  );
};

export default TvDashboard;

