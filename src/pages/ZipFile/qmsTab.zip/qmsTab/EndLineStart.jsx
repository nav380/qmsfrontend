import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { Box, Button, Menu, MenuItem } from '@mui/material';
import { MaterialReactTable, createMRTColumnHelper, useMaterialReactTable } from 'material-react-table';
import Skeleton from 'react-loading-skeleton';
import { toast } from 'react-toastify';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import DjangoConfig from '../../config/Config';
import { saveRows } from '../../utils/slice/SewingInputSlice';
const EndLineStart = () => {
    const navigate = useNavigate()
    const [isLoading, setIsLoading] = useState(false)
    const dispatch = useDispatch()
    const userData = useSelector(state => state.user.userData);
    const [tableData, setTableData] = useState([])

    console.log("userData", userData)

    useEffect(() => {
        fetchPlaningData();

    }, [])


    const fetchPlaningData = () => {
        setIsLoading(true)
        const userData2 = {
            line_id: userData.line_id,
            process_id :userData.process_id,
            section_id :userData.section_id
        };
        // buyer_data
        console.log("endline",userData2)
        const queryParams = new URLSearchParams(userData2).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/sewing_line_dt_input/?${queryParams}`, {
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {
                const responseData = response.data.buyer_data
                console.log(response.data)
                setTableData(responseData)
                setIsLoading(false)
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };
    // console.log("buyerData",buyerData)

    const handleExportRows = (rows) => {
       
            if (rows && rows.length > 0 && rows[0].original) {
                const rowData = rows[0].original;
                const sewingData = {
                    id : rowData.id,
                    buyer: rowData.buyer,
                    styleno: rowData.style,
                    color: rowData.color,
                    quantity: rowData.total_input_qty,
                    delvdate: rowData.delvdate,
                    line_id: userData.line_id,
                    ourref :rowData.ourref,
                    buyer_name : rowData.buyer_name,
                    process_name: userData.process_name,
                    process_id:userData.process_id,
                    section_name : userData.section_name,
                    section_id: userData.section_id,
                };
                
                dispatch(saveRows(sewingData));
                navigate('/qms-tab/qc-section');
            }
            else{
                toast.error("Invalid rows or missing  property")
            }
    };
    
     




    const columnHelper = createMRTColumnHelper();
    const columns = [
        columnHelper.accessor((row, index) => index + 1, { header: 'S/N', size: 40 }),
        columnHelper.accessor('buyer_name', { header: 'Buyer', size: 20 }),
        columnHelper.accessor('style', { header: 'Style No', size: 20 }),
        columnHelper.accessor('color', { header: 'Color ', size: 20 }),
        columnHelper.accessor('total_input_qty', { header: 'Quantity', size: 20 }),
        columnHelper.accessor('delvdate', { header: 'Delivery Date', size: 20 }),
    ];



    const table = useMaterialReactTable({
        columns,
        data: tableData,
        state: {
            isLoading: isLoading ? <Skeleton count={5} /> : null,

        },
        enableMultiRowSelection: false, //shows radio buttons instead of checkboxes
        enableRowSelection: true,
        columnFilterDisplayMode: 'popover',
        paginationDisplayMode: 'pages',
        positionToolbarAlertBanner: 'bottom',
        renderTopToolbarCustomActions: ({ table }) => (
            <Box
                sx={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px',
                    flexWrap: 'wrap',
                }}
            >
                <Button
                    disabled={!table.getIsSomeRowsSelected() && !table.getIsAllRowsSelected()}
                    onClick={() => handleExportRows(table.getSelectedRowModel().rows)}
                    startIcon={<FileDownloadIcon />}
                >
                    Select Planing Line
                </Button>
            </Box>
        ),
    });
    

    return (
        <div>

            <div className='mt-2'>
                <MaterialReactTable table={table} />
            </div>

        </div>
    );
};

export default EndLineStart;
