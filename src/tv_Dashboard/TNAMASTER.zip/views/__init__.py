from .tna_template import TnaTemplateView
from .tna_template_history import TnaTemplateHistoryView
from .tna_entry import TnaEntryView
from .tna_entry_history import TnaEntryHistoryView