import { useEffect, useState } from 'react';
import {  useParams } from 'react-router-dom';
import DjangoConfig from '../../config/Config';
import axios from 'axios';

const ViewUserPermission = () => {
    const [tableData, setTableData] = useState([]);
    const { userId } = useParams();

    useEffect(() => {
        fetchUserPermissionData();
    }, []);

    const fetchUserPermissionData = async () => {
    
        console.log("User Id ", userId);
        
        try {
            const url = `${DjangoConfig.apiUrl}/rtqm/qms_user_master/?user_id=${userId}`;
            const response = await axios.get(url);
            if (response.status === 200) {
                setTableData(response.data.permission_data);
                console.log(response.data);
            } else {
                console.warn("Received unexpected status code:", response.status);
            }
        } catch (err) {
            console.error("Error fetching user master data:", err);
        }
    };

    return (
        <div>
            <h1>User Permissions</h1>
            {tableData.length === 0 ? (
                <p>No data available</p>
            ) : (
                <table>
                    <thead>
                        <tr>
                            <th>Process</th>
                            <th>Section</th>
                            <th>Unit</th>
                            <th>Floor</th>
                            <th>Line</th>

                            {/* Add more headers as needed */}
                        </tr>
                    </thead>
                    <tbody>
                        {tableData.map(user => (
                            <tr key={user.id}>
                                <td>{user.process__name}</td>
                                <td>{user.section__name}</td>
                                <td>{user.unit_name}</td>
                                <td>{user.floor_name}</td>
                                <td>{user.line_name}</td>

                                {/* Add more columns as needed */}
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
};

export default ViewUserPermission;
