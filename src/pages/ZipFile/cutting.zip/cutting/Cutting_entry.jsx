import { useEffect, useRef, useState } from "react";
import axios from "axios";
import DjangoConfig from "../../config/Config";
import Select from 'react-select';
import Skeleton from "react-loading-skeleton";
import { toast } from "react-toastify";
import { useNavigate } from 'react-router-dom';
import { Button } from '@mui/material';

import makeAnimated from 'react-select/animated';



const animatedComponents = makeAnimated();

const CuttingEntryForm = () => {
    const navigate = useNavigate()
    const [selectedBuyer, setSelectedBuyer] = useState(null);
    const [buyerList, setBuyerList] = useState([]);
    const [selectedStyle, setSelectedStyle] = useState(null);
    const [styleNoData, setStyleNoData] = useState([]);
    const [selectedOrderno, setSelectedOrderno] = useState(null);
    const [orderData, setOrderData] = useState([]);
    const [selectedColor, setSelectedColor] = useState(null);
    const [colorData, setColorData] = useState([]);
    const [fabricDetail, setFabricDetail] = useState(null);
    const [fabricData, setFabricData] = useState([]);
    const [selectedcuttingmaster, setSelectedCuttingMaster] = useState(null);
    const [cuttingmasData, setCuttingMasData] = useState([]);
    const [orderQuantity, setOrderQuantity] = useState(0);
    const [orderDate, setOrderDate] = useState('');
    const [layerNumber, setLayerNumber] = useState(0);
    const [tableNumber, setTableNumber] = useState(0);
    const [fabricUsed, setFabricUsed] = useState('');
    const [grossAverage, setGrossAverage] = useState(0);
    const [layerStartDateTime, setLayerStartDateTime] = useState('');
    const [layerEndDateTime, setLayerEndDateTime] = useState('');
    const [layerCutStart, setLayerCutStart] = useState('');
    const [layerCutEnd, setLayerCutEnd] = useState('');
    const [plies, setPlies] = useState("" || 0);
    const [totalCutPcs, setTotalCutPcs] = useState(0);
    const [selectedcuttingtype, setSelectedCuttingtype] = useState(null);
    const [deliveryDate, setDeliveryDate] = useState([]);
    const [selectedDeliveryDates, setSelectedDeliveryDates] = useState([]);
    const formRef = useRef(null);
    //================ second form data ================================================
    const [selectedSizes, setSelectedSizes] = useState([]);
    const [sizeData, seSizeData] = useState([]);
    const [selectedRatios, setSelectedRatios] = useState([]);
    const [sizeWiseBreakup, setSizeWiseBreakup] = useState([]);
    // const [dates, setDates] = useState([""]);
    // const [inputValue, setInputValue] = useState("");




    // ============================================ First form function ====================================================================
    //    save data function
    // console.log("pppppppppppppppp==>",selectedcuttingmaster)
    const saveData = (event) => {
        event.preventDefault();
        if (!selectedBuyer || !selectedStyle || !selectedOrderno || !selectedColor || !layerStartDateTime || !layerEndDateTime || !layerCutStart || !layerCutEnd || !layerNumber || !tableNumber || !fabricUsed || !grossAverage) {
            toast.error("Please fill out all required fields.");
            return;
        }
        if (selectedSizes.length === selectedRatios.length) {
            const userData = {
                buyer: selectedBuyer.value,
                buyer_name: selectedBuyer.label,
                style: selectedStyle.value,
                orderno: selectedOrderno.value,
                color: selectedColor?.value || "",
                orderQuantity: orderQuantity,
                orderDate: orderDate,
                deliveryDate: deliveryDate,
                layerNumber: layerNumber,
                tableNumber: tableNumber,
                fabricUsed: fabricUsed,
                grossAverage: grossAverage,
                layerStartDateTime: layerStartDateTime,
                layerEndDateTime: layerEndDateTime,
                layerCutStart: layerCutStart,
                layerCutEnd: layerCutEnd,
                sizelist: selectedSizes,
                ratiolist: selectedRatios,
                pliesquantity: plies,
                fabricDetail: fabricDetail,
                totalCutPcs: totalCutPcs,
                cutpcsquantityBySize: sizeWiseBreakup,
                cutting_master: selectedcuttingmaster.label,
                created_by: selectedcuttingmaster.value,
                cuttying_type: selectedcuttingtype.value
            };
            console.log("Sending data:", userData);
            const url = `${DjangoConfig.apiUrl}/rtqm/layer_cutting/`;
            axios.post(url, userData)
                .then((res) => {
                    console.log('ooooooooooo', res.data.cuttingno)
                    const cuttingno = res.data.cuttingno
                    toast.success(cuttingno + " Data saved successfully");
                })
                .catch((e) => {
                    toast.error("Error saving data.");
                });
        }
        else{
            toast.error(" Size and ratio value should be Equal");
        }
    };

    //1--> fetch buyer initiall data 
    const fetchInitialData = async () => {
        try {
            const response = await axios.get(`${DjangoConfig.apiUrl}/rtqm/qms_planing/`);
            setBuyerList(response.data.buyer_list.map(item => ({ value: item.buyer_code, label: item.buyer_name })));
            console.log('initialresponse', response.data.buyer_list)
        } catch (error) {
            console.error('Error fetching initial data:', error);
        }
    };

    // useState hook
    useEffect(() => {
        fetchInitialData();
        fetchCuttingMaster()
    }, []);

    //1.h----> handle buyer selection
    const handleBuyerChange = (selectedValue) => {
        setSelectedBuyer(selectedValue);
        fetchByBuyer(selectedValue);
    };

    //2---> fetch style by buyer
    const fetchByBuyer = (selectedValue) => {
        const userData = { buyer_filter: selectedValue.value };
        const queryParams = new URLSearchParams(userData).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/excel_data_show_view/?${queryParams}`)
            .then(response => {
                const responseData = response.data.data;
                console.log('fetchByBuyer----->', responseData)
                const uniqueStyles = [...new Set(responseData.map(item => item.styleno))];
                const styleOptions = uniqueStyles.map(style => ({ value: style, label: style }));
                setStyleNoData(styleOptions);
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };
    //2.h -------> handle style selection
    const handleStyleChange = (selectedValue) => {
        setSelectedStyle(selectedValue);
        fetchByStyle(selectedValue);
    };

    //3----------> fetch orderno by buyer and style 
    const fetchByStyle = (selectedValue) => {
        const userData = { buyer_filter: selectedBuyer.value, style_filter: selectedValue.value };
        const queryParams = new URLSearchParams(userData).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/layer_cutting/?${queryParams}`)
            .then(response => {
                const responseData = response.data.data;
                console.log('fetchByStyle-------->', responseData);
                const uniqueOrderno = [...new Set(responseData.map(item => item.ourref))];
                const orderOptions = uniqueOrderno.map(order => ({ value: order, label: order }));
                setOrderData(orderOptions);
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };

    //3.h--------> handle orderno selection
    const handleOrderno = (selectedValue) => {
        setSelectedOrderno(selectedValue);
        fetchByOrderno(selectedValue);
    };

    //4-------> Fetch color,total quantityData, orderDate by buyer, style and orderno 
    const fetchByOrderno = (selectedValue) => {
        const userData = { buyer_filter: selectedBuyer.value, style_filter: selectedStyle.value, orderno_filter: selectedValue.value };
        console.log('userData ---------->', userData);
        const queryParams = new URLSearchParams(userData).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/layer_cutting/?${queryParams}`)
            .then(response => {
                const responseData = response.data.data;
                const responseData1 = response.data.data1
                const responseData2 = response.data.data1.data
                console.log('fetchByOrderno------->', responseData1);
                setOrderDate(responseData2[0].orderdate)
                setOrderQuantity(responseData2[0].totalqty)
                //  color list maping 
                const uniqueColor = [...new Set(responseData.map(item => item.color))];
                const colorOptions = uniqueColor.map(color => ({ value: color, label: color }));
                console.log('colorOptions --------->', colorOptions)
                setColorData(colorOptions);
                //  Delivery date list maping        
                const uniquedelvdate = [...new Set(responseData1.delvdate.map(item => item.ExDelvDate.split('T')[0]))];
                const delvdateOptions = uniquedelvdate.map(ExDelvDate => ({ value: ExDelvDate, label: ExDelvDate }));
                console.log('delvdateOptions --------->', delvdateOptions)
                setDeliveryDate(delvdateOptions)
                //  Fabric list maping 
                const uniquefabric = [...new Set(responseData1.fabricdetail.map(item => item.ITEM))];
                const fabricOptions = uniquefabric.map(item => ({ value: item, label: item }));
                console.log('fabricOptions --------->', fabricOptions)
                setFabricData(fabricOptions)
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };
    // 4.h-----------> handle color selection
    const handleColor = (selectedValue) => {
        setSelectedColor(selectedValue);
        fetchByColor(selectedValue);
    };

    //5-------> Fetch size data by buyer, style and orderno and color 
    const fetchByColor = (selectedValue) => {
        const userData = { buyer_filter: selectedBuyer.value, style_filter: selectedStyle.value, orderno_filter: selectedOrderno.value, color_filter: selectedValue.value };
        console.log('userData ---------->', userData);
        const queryParams = new URLSearchParams(userData).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/layer_cutting/?${queryParams}`)
            .then(response => {
                const responseData = response.data.data1;
                console.log('fetchByColor-------->', responseData)
                const uniquesize = [...new Set(responseData.map(item => item.sizeval))];
                const sizeOptions = uniquesize.map(size => ({ value: size, label: size }));
                seSizeData(sizeOptions);
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };

    // fetching  cutting master 
    const fetchCuttingMaster = () => {
        axios.get(`${DjangoConfig.apiUrl}/rtqm/layer_cutting/`)
            .then(response => {
                console.log("cutingmaster-------->", response.data);
                const responseData = response.data.cutting_master;
                // const uniquecutmaster = [...new Set(responseData.map(item => item.emp_paycode))];
                // console.log('uniquecutmaster==========>', uniquecutmaster)
                const masterOptions = responseData.map(item => ({ value: item.emp_code, label: `${item.emp_name} (${item.emp_paycode})` }));
                console.log("llllllllllllllllllll===>", masterOptions)
                setCuttingMasData(masterOptions);
            })
            .catch(error => {
                console.log('Error fetching filtered data:', error);
            });
    };



    //=============================== second form function ==============================================================

    //  ratio selection 
    const ratioOptions = [
        { label: "1", value: 1 },
        { label: "2", value: 2 },
        { label: "3", value: 3 },
        { label: "4", value: 4 },
        { label: "5", value: 5 },
        { label: "6", value: 6 },
        { label: "7", value: 7 },
        { label: "8", value: 8 },
        { label: "9", value: 9 },
        { label: "10", value: 10 },
    ];
    const cuttingtypeOptions = [
        { label: "Main body", value: "Main body" },
        { label: "trim", value: "trim" },

    ];

    // Total cutpcs calculation
    const calculateTotalCutPcs = () => {
        const totalRatio = selectedRatios.reduce((sum, item) => sum + item.value, 0);
        const totalCut = (plies || 0) * totalRatio;
        setTotalCutPcs(isNaN(totalCut) ? 0 : totalCut);
    };

    // cutpcs size wise breakup
    const calculateSizeBreakup = () => {
        const sizeBreakup = selectedSizes.map((size, index) => {
            const ratioValue = selectedRatios[index] ? selectedRatios[index].value : 0;
            return {
                size: size.label,
                quantity: (plies || 0) * ratioValue
            };
        });
        setSizeWiseBreakup(sizeBreakup);
    };

    // fabric detail selection handling 
    const handleFabricDetailChange = (selectedOption) => {
        console.log(selectedOption)
        setFabricDetail(selectedOption);
    };
    // size selection Handling
    const handleSizeChange = (selectedOption) => {
        setSelectedSizes((prevSelectedSizes) => [...prevSelectedSizes, selectedOption]);
    };

    // delivery date selection handling 
    const handleDeliveryDateChange = (selectedOption) => {
        if (selectedOption && !selectedDeliveryDates.some(date => date.value === selectedOption.value)) {
            setSelectedDeliveryDates((prevSelectedDeliveryDates) => [...prevSelectedDeliveryDates, selectedOption]);
        }
    };

    // size selection management
    const availableSizeOptions = sizeData.filter(option =>
        !selectedSizes.some(selected => selected.value === option.value)
    );
    // ration change handling
    const handleRatioChange = (selectedOption) => {
        setSelectedRatios((prevSelectedRatios) => [...prevSelectedRatios, selectedOption]);
    };
    // select size removing handle
    const removeSize = (index) => {
        setSelectedSizes((prevSelectedSizes) => prevSelectedSizes.filter((_, i) => i !== index));
    };
    // select ratio removing handle
    const removeRatio = (index) => {
        setSelectedRatios((prevSelectedRatios) => prevSelectedRatios.filter((_, i) => i !== index));
    };
    // select deliverydate removing handle
    const removeDeliveryDate = (index) => {
        setSelectedDeliveryDates((prevSelectedDeliveryDates) => prevSelectedDeliveryDates.filter((_, i) => i !== index));
    };
    // select deliverydate management
    // const availableDeliveryDateOptions = deliveryDateOptions.filter(option =>
    //     !selectedDeliveryDates.some(selected => selected.value === option.value)
    // );

    // useEffect hook
    useEffect(() => {
        calculateTotalCutPcs();
        calculateSizeBreakup();
    }, [plies, selectedRatios, selectedSizes]);

    const obTablePage = () => {
        navigate('/dashboard/cutting_route/history/')
    }

    return (
        <>
            <div className='w-full h-8 flex items-center justify-end  rounded-lg pt-8 pr-14 '>
                <Button
                    onClick={obTablePage}
                    variant="contained"
                    color="primary"
                    className="float-right mr-2 "
                >
                    History
                </Button>
            </div>
            {/*==================================== first form ================================================ */}
            <div className=" pl-12 pr-12">
                <div className="text-2xl mb-2 text-slate-950 font-bold">
                    Actual Cutting Entry (Layer)
                </div>
                <form onSubmit={saveData} ref={formRef} className="mt-1">
                    <div className="grid grid-cols-1 sm:grid-cols-4 md:grid-cols-4 gap-3 mb-2">
                        <div>
                            <label htmlFor="buyerList">Buyer</label>
                            <Select
                                options={buyerList}
                                value={selectedBuyer}
                                onChange={handleBuyerChange}
                                name="buyer"
                                placeholder="Select Buyer"
                                className="w-full border-2 border-gray-300 rounded-md outline-none"
                                isSearchable
                                isLoading={!buyerList.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>
                        <div>
                            <label htmlFor="styleNoData">Style No</label>
                            <Select
                                options={styleNoData}
                                value={selectedStyle}
                                onChange={handleStyleChange}
                                name="style_no"
                                placeholder="Select Style"
                                className="w-full border-2 border-gray-300 rounded-md"
                                isSearchable
                                isLoading={!styleNoData.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>
                        <div>
                            <label htmlFor="orderData">Order No</label>
                            <Select
                                options={orderData}
                                value={selectedOrderno}
                                onChange={handleOrderno}
                                placeholder="Select Order No"
                                className="w-full border-2 border-gray-300 rounded-md"
                                isSearchable
                                isLoading={!orderData.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>
                        <div>
                            <label htmlFor="colorData">Color</label>
                            <Select
                                options={colorData}
                                value={selectedColor}
                                onChange={handleColor}
                                placeholder="Select Color"
                                className="w-full border-2 border-gray-300 rounded-md"
                                isSearchable
                                isLoading={!colorData.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>

                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-2">
                        <div className="form-group">
                            <label htmlFor="fabric_detail" className="block text-sm font-normal mb-2">Fabric Detail</label>
                            <Select
                                options={fabricData}
                                value={fabricDetail}
                                onChange={handleFabricDetailChange}
                                name="fabric_name"
                                placeholder="Fabric Detail"
                                className="border-2 w-full border-gray-400 rounded-md"
                                isSearchable
                                isLoading={!fabricData.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                    }),
                                }}
                            />
                        </div>
                        <div>
                            <label htmlFor="colorData">Cutting Master</label>
                            <Select
                                options={cuttingmasData}
                                value={selectedcuttingmaster}
                                onChange={setSelectedCuttingMaster}
                                placeholder="Select Color"
                                className="w-full border-2 border-gray-300 rounded-md"
                                isSearchable
                                isLoading={!cuttingmasData.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>
                        <div>
                            <label htmlFor="orderQuantity">Order Quantity</label>
                            <input
                                type="number"
                                id="orderQuantity"
                                value={orderQuantity}
                                // onChange={(e) => setOrderQuantity(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="orderDate">Order Date</label>
                            <input
                                type="datetime-local"
                                id="orderDate"
                                value={orderDate}
                                // onChange={(e) => setOrderDate(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>

                        <div>
                            <label htmlFor="layerNumber">Layer Number</label>
                            <input
                                type="text"
                                id="layerNumber"
                                value={layerNumber}
                                onChange={(e) => setLayerNumber(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="tableNumber">Table Number</label>
                            <input
                                type="text"
                                id="tableNumber"
                                value={tableNumber}
                                onChange={(e) => setTableNumber(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="fabricUsed">Fabric Used</label>
                            <input
                                type="text"
                                id="fabricUsed"
                                value={fabricUsed}
                                onChange={(e) => setFabricUsed(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="grossAverage">Gross Average</label>
                            <input
                                type="number"
                                id="grossAverage"
                                value={grossAverage}
                                onChange={(e) => setGrossAverage(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="layerStartDateTime">Layer Start DateTime</label>
                            <input
                                type="datetime-local"
                                id="layerStartDateTime"
                                value={layerStartDateTime}
                                onChange={(e) => setLayerStartDateTime(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="layerEndDateTime">Layer End DateTime</label>
                            <input
                                type="datetime-local"
                                id="layerEndDateTime"
                                value={layerEndDateTime}
                                onChange={(e) => setLayerEndDateTime(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="layerCutStart">Layer Cut Start</label>
                            <input
                                type="datetime-local"
                                id="layerCutStart"
                                value={layerCutStart}
                                onChange={(e) => setLayerCutStart(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                        </div>
                        <div>
                            <label htmlFor="layerCutEnd">Layer Cut End</label>
                            <input
                                type="datetime-local"
                                id="layerCutEnd"
                                value={layerCutEnd}
                                onChange={(e) => setLayerCutEnd(e.target.value)}
                                className="w-full border-2 border-gray-300 rounded-md p-2 outline-none"
                            />
                            {/* </div> */}
                        </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-5 md:grid-cols-5 gap-4 mb-2">
                        <div className="form-group">
                            <label className="block text-sm font-normal mb-1">Plies</label>
                            <input
                                type="number"
                                className="border border-gray-300 w-full rounded-md p-2 pl-3"
                                value={plies}
                                onChange={(e) => setPlies(Number(e.target.value) || "")}
                                onFocus={(e) => e.target.value === "0" && setPlies("")}
                            />
                        </div>

                        <div className="form-group">
                            <label className="block text-sm font-normal mb-2">No of PCS Cut</label>
                            <input
                                type="text"
                                className="border border-gray-300 w-full rounded-md p-2"
                                value={totalCutPcs}
                                readOnly
                            />
                        </div>
                        <div>
                            <label htmlFor="colorData">Cutting Type</label>
                            <Select
                                options={cuttingtypeOptions}
                                value={selectedcuttingtype}
                                onChange={setSelectedCuttingtype}
                                placeholder="Select cutting type"
                                className="w-full border-2 border-gray-300 rounded-md"
                                isSearchable
                                isLoading={!cuttingtypeOptions.length}
                                loadingMessage={() => <Skeleton count={5} />}
                                isClearable
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        height: '40px',
                                        fontSize: '12px',
                                        borderColor: '#d1d5db', // Light gray border color
                                    }),
                                }}
                            />
                        </div>

                        <div className="form-group">
                            <label className="block text-sm font-medium mb-2">Delivery Dates</label>
                            <Select
                                closeMenuOnSelect={false}
                                components={animatedComponents}
                                options={deliveryDate}
                                onChange={handleDeliveryDateChange}
                                className="border border-gray-300 rounded-md"
                                placeholder="Delivery Dates"
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        borderColor: '#d1d5db',
                                        boxShadow: 'none',
                                        fontSize: '12px',
                                        width: '100%',
                                        '&:hover': {
                                            borderColor: '#d1d5db',
                                        },
                                    }),
                                }}
                            />
                        </div>

                        <div className="flex flex-wrap mb-2 ">
                            {(selectedDeliveryDates.length > 0) ? (selectedDeliveryDates.map((date, index) => (
                                <div key={index} className="h-8 bg-gray-200 rounded px-1 py-1 m-1 flex items-center">
                                    {date.label}
                                    <button
                                        type="button"
                                        className="ml-2 text-red-500"
                                        onClick={() => removeDeliveryDate(index)}
                                    >
                                        &times;
                                    </button>
                                </div>
                            ))) : (<div className='h-8  bg-gray-200 rounded px-2 py-1 m-1 flex items-center'>
                                Select delivery date <button type="button" className="ml-2 text-red-500"> &times;
                                </button></div>)}
                        </div>

                    </div>


                    {/* =============================================== Second form starting  ========================================= */}

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-4 mb-4">

                        <div className="form-group">
                            <label className="block text-sm font-medium mb-2">Select Sizes</label>
                            <div className="flex flex-wrap mb-2">
                                {(selectedSizes.length > 0) ? (selectedSizes.map((size, index) => (
                                    <div key={index} className="inline-block bg-gray-200 rounded px-2 py-1 m-1 flex items-center">
                                        {size.label}
                                        <button
                                            type="button"
                                            className="ml-2 text-red-500"
                                            onClick={() => removeSize(index)}
                                        >
                                            &times;
                                        </button>
                                    </div>
                                ))) : (<div className='bg-gray-200 rounded px-2 py-1 m-1 flex items-center'>
                                    Select a size <button type="button" className="ml-2 text-red-500"> &times;
                                    </button></div>)}
                            </div>
                            <Select
                                closeMenuOnSelect={false}
                                components={animatedComponents}
                                options={availableSizeOptions}
                                onChange={handleSizeChange}
                                className="border border-gray-300 rounded-md"
                                placeholder="Select Sizes"
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        borderColor: '#d1d5db',
                                        boxShadow: 'none',
                                        fontSize: '12px',
                                        width: '100%',
                                        '&:hover': {
                                            borderColor: '#d1d5db',
                                        },
                                    }),
                                }}
                            />
                        </div>
                        <div className="form-group">
                            <label className="block text-sm font-medium mb-2">Ratio</label>
                            <div className="flex flex-wrap mb-1">
                                {(selectedRatios.length > 0) ? (selectedRatios.map((ratio, index) => (
                                    <div key={index} className="inline-block bg-gray-200 rounded px-2 py-1 m-1 flex items-center">
                                        {ratio.label}
                                        <button
                                            type="button"
                                            className="ml-2 text-red-500"
                                            onClick={() => removeRatio(index)}
                                        >
                                            &times;
                                        </button>
                                    </div>
                                ))) : ((<div className='bg-gray-200 rounded px-2 py-1 m-1 flex items-center'>
                                    Select a Ratio <button type="button" className="ml-2 text-red-500"> &times;
                                    </button></div>))}
                            </div>
                            <Select
                                closeMenuOnSelect={false}
                                components={animatedComponents}
                                options={ratioOptions}
                                onChange={handleRatioChange}
                                className="border border-gray-300 rounded-md"
                                placeholder="Select Ratios"
                                styles={{
                                    control: (provided) => ({
                                        ...provided,
                                        borderColor: '#d1d5db',
                                        boxShadow: 'none',
                                        width: '100%',
                                        fontSize: '12px',
                                        '&:hover': {
                                            borderColor: '#d1d5db',
                                        },
                                    }),
                                }}
                            />
                        </div>



                        <div className="form-group">
                            <label className="block text-sm font-medium mb-2">Size Wise Breakup</label>
                            <div className="border border-gray-300 w-full rounded-md p-2">
                                {sizeWiseBreakup.length > 0 ? (
                                    <ul className="flex justify-start items-center">
                                        {sizeWiseBreakup.map((item, index) => (
                                            <li key={index} className="ml-3">
                                                {item.size}: {item.quantity}
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p>No data available</p>
                                )}
                            </div>
                        </div>
                        <div className="w-36 ctext-center absolute bottom-8 right-36">
                            <button
                                type="submit"
                                className="w-36 bg-blue-500 text-white px-6 py-2 rounded-md shadow-md hover:bg-blue-700"
                            >
                                Save
                            </button>
                        </div>
                    </div>
                </form>
            </div>

        </>
    );
};
export default CuttingEntryForm;
