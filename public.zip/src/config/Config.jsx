const DjangoConfig = {
    apiUrl: 'http://103.190.95.164:12001',
    isAppUrl :'http://103.190.95.164:11002',
};

export default DjangoConfig;

