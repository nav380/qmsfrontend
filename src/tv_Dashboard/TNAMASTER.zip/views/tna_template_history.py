from django.views import View
from django.shortcuts import redirect, render
from django.contrib import messages
from App_db.models import TnaTemplateMt 
from IntelliSync_db.models import UserPermissionMaster
from django.db.models import Q


class TnaTemplateHistoryView(View):
    def get(self, request):
          permission_code = ''
          try:
               user_permission = UserPermissionMaster.objects.get(
                     Q(user=request.user) & (Q(permission_permission_code='AHOD'))
                 )
               if user_permission.permission.permission.code == 'AHOD':
                   permission_code=user_permission.permission.permission.code
          except:
               pass
          
          template_data = TnaTemplateMt.objects.all()
          flag = request.GET.get("flag")
          if flag == 'approve':
               at_id = request.GET.get("id")
               TnaTemplateMt.objects.filter(id=at_id).update(status = 'approved')
               messages.success(request, "Template Status Approved")
          context = {
               'template_data': template_data,
               'permission_code': permission_code
          }

          print(context)
          
          return render(request, 'T&A_Template_History.html', context)
          
