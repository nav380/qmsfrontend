import { useState, useEffect } from 'react';
import axios from 'axios';
import { MaterialReactTable, useMaterialReactTable, createMRTColumnHelper } from 'material-react-table';
import { Box, Button, Menu, MenuItem } from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { mkConfig, generateCsv, download } from 'export-to-csv';
import DjangoConfig from "../../config/Config";
import { useNavigate } from 'react-router-dom';

const Cutting_History = () => {
  const [data, setData] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const columnHelper = createMRTColumnHelper();
  const navigate = useNavigate()

  // Fetch data
  const loaddata = () => {
    const url = `${DjangoConfig.apiUrl}/rtqm/layer_cuttingDt/`;
    axios.get(url).then((resp) => {
      setData(resp.data.data);
      console.log(resp.data.data)
    }).catch((error) => {
      console.error('Error fetching data:', error);
    });
  };

  useEffect(() => {
    loaddata();
  }, []); // Dependency array is empty to run only once on component mount

  // Define columns
  const columns = [
    columnHelper.accessor('id', { header: 'ID', size: 40 }),
    columnHelper.accessor('cuttingno', {
      header: 'Cutting No', size: 120,
      Cell: ({ cell }) => (
        <span onClick={() => detailviews(cell.row.original)}
          style={{
            color: 'blue',
            cursor: 'pointer'
          }}>
          {cell.getValue()}
        </span>
      ),
    }),
    columnHelper.accessor('buyer', { header: 'Buyer', size: 120 }),
    columnHelper.accessor('style', { header: 'Style', size: 120 }),
    columnHelper.accessor('ourref', { header: 'OrderNo', size: 120 }),
    columnHelper.accessor('color', { header: 'Color', size: 120 }),
    columnHelper.accessor('fabric_item', { header: 'Fabric Detail', size: 120 }),
    columnHelper.accessor('cutting_master', { header: 'Cutting Master', size: 120 }),
    columnHelper.accessor('orderqty', { header: 'Order Quantity', size: 120 }),
    columnHelper.accessor('orderdate', { header: 'Order Date', size: 120 }),
    columnHelper.accessor('delvdate', { header: 'Delivery Date', size: 120 }),
    columnHelper.accessor('layerno', { header: 'Layer Number', size: 120 }),
    columnHelper.accessor('tablno', { header: 'Table No', size: 120 }),
    columnHelper.accessor('fabric_use', { header: 'Fabric Used', size: 120 }),
    columnHelper.accessor('grossAverage', { header: 'Gross Average', size: 120 }),
    columnHelper.accessor('layerstart', { header: 'Ls DateTime', size: 150 }),
    columnHelper.accessor('layerend', { header: 'Le DateTime', size: 150 }),
    columnHelper.accessor('cuttingstart', { header: 'Cs DateTime', size: 150 }),
    columnHelper.accessor('cuttingend', { header: 'Ce DateTime', size: 150 }),
    columnHelper.accessor('plies', { header: 'Plies', size: 80 }),
    columnHelper.accessor('totalqty', { header: 'No Of PCS Cut', size: 120 }),
    columnHelper.accessor('size', { header: 'Size', size: 120 }),
    columnHelper.accessor('created_by', { header: 'Created By', size: 150 }),
    columnHelper.accessor('created_at', { header: 'Created At', size: 150 }),
  ];

  const detailviews = (row) => {
    console.log("id=============>", row.id)
    navigate("/dashboard/cutting_route/detail/", {
      state: {
        id: row.id,
      }
    });
  };

  const csvConfig = mkConfig({
    fieldSeparator: ',',
    decimalSeparator: '.',
    useKeysAsHeaders: true,
  });

  const handleExportRows = (rows) => {
    const rowData = rows.map((row) => row.original);
    const csv = generateCsv(csvConfig)(rowData);
    download(csvConfig)(csv);
  };

  const handleExportData = () => {
    const csv = generateCsv(csvConfig)(data);
    download(csvConfig)(csv);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const table = useMaterialReactTable({
    columns,
    data,
    editDisplayMode: 'modal',
    getRowId: (row) => row.id,
    muiToolbarAlertBannerProps: !data.length
      ? { color: 'error', children: 'Error loading data' }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '100px',
      },
    },
    paginationDisplayMode: 'pages',
    positionToolbarAlertBanner: 'bottom',
    enableEditing: true,
    muiTableBodyCellProps: {
      sx: {
        border: '1px solid rgba(81, 81, 81, .5)',
      },
    },
    renderTopToolbarCustomActions: ({ table }) => (
      <Box
        sx={{
          display: 'flex',
          gap: '10px',
          padding: '4px',
          flexWrap: 'wrap',
        }}
      >
        <Button
          aria-controls="export-menu"
          aria-haspopup="true"
          onClick={handleClick}
          startIcon={<FileDownloadIcon />}
        >
          Export
        </Button>
        <Menu
          id="export-menu"
          anchorEl={anchorEl}
          keepMounted
          open={Boolean(anchorEl)}
          onClose={handleClose}
        >
          <MenuItem onClick={handleExportData}>Export All Data</MenuItem>
          <MenuItem
            disabled={table.getPrePaginationRowModel().rows.length === 0}
            onClick={() => handleExportRows(table.getPrePaginationRowModel().rows)}
          >
            Export All Rows
          </MenuItem>
          <MenuItem
            disabled={table.getRowModel().rows.length === 0}
            onClick={() => handleExportRows(table.getRowModel().rows)}
          >
            Export Page Rows
          </MenuItem>
        </Menu>
      </Box>
    ),
  });

  const obTablePage =()=>{
    navigate('/dashboard/cutting_route/cutting1/')
  }

  return (
    <>
      <div className='w-full h-10 flex items-center justify-end  rounded-lg p-8'>
        <Button
          onClick={obTablePage}
          variant="contained"
          color="primary"
          className="float-right mr-2 "
        >
          Add Data
        </Button>
      </div>
      <div className="p-3">
        <MaterialReactTable table={table} />
      </div>
    </>
  );
};

export default Cutting_History;
