import React, { useEffect, useState } from 'react';
import logo from './favicon.ico';

const TVDashboard2 = () => {
  const [time, setTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, '0');
      const seconds = now.getSeconds().toString().padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      const hoursStr = hours.toString().padStart(2, '0');
      setTime(`${hoursStr}:${minutes}:${seconds} ${ampm}`);
    };

    const timerId = setInterval(updateTime, 1000);
    updateTime();

    return () => clearInterval(timerId);
  }, []);

  return (
    <section id="dashboard" className="bg-black h-screen">
      <header>
        <nav className="bg-[#070F2B] border-2 border-slate-500 w-full h-20 flex items-center justify-between">
          <div className="flex items-center justify-center border-r border-black w-1/5 h-full">
            <a href="#" className="flex items-center justify-center">
              <img src={logo} alt="logo" className="mr-2" />
              <span className="text-goldenrod text-2xl text-white font-semibold">IntelliSYNC</span>
            </a>
          </div>
          <div className="flex-grow flex items-center justify-center border-r border-black w-3/5 h-full">
            <span className="text-goldenrod font-bold text-white text-3xl">Sewing Dashboard</span>
          </div>
          <div className="flex items-center justify-center w-1/5 h-full">
            <div id="time" className="text-goldenrod mt-6 text-white text-2xl font-bold ml-10">{time}</div>
          </div>
        </nav>

        <div className="bg-black w-full h-14 flex items-center justify-between border-t-2 border-b-2 border-slate-500 mt-1">
          <div className="flex items-center justify-center border-r border-black w-1/5 h-full">
            <span className="text-teal text-xl text-white font-semibold">Line</span>
          </div>
          <div className="flex items-center justify-center border-r border-black w-1/5 h-full">
            <span className="text-teal text-xl text-white font-semibold">Buyer</span>
          </div>
          <div className="flex items-center justify-center border-r border-black w-1/5 h-full">
            <span className="text-teal text-xl text-white font-semibold">Style</span>
          </div>
          <div className="flex items-center justify-center border-r border-black w-1/5 h-full">
            <span className="text-teal text-xl text-white font-semibold">Colour</span>
          </div>
          <div className="flex items-center justify-center w-1/5 h-full">
            <span className="text-teal text-xl text-white font-semibold">Hour No</span>
          </div>
        </div>

        <div className="flex h-full">
          <div className="border-2 border-slate-500 w-1/3 h-5/6 flex items-center justify-center">
            <span className="text-chocolate text-xl text-slate-200 font-semibold">Front</span>
          </div>
          <div className="border-2 border-slate-500 w-7/12 h-5/6 mx-3 flex items-center justify-center">
            <span className="text-chocolate text-xl text-slate-200 h-80 font-semibold">Back</span>
          </div>
          <div className="w-1/5 h-5/6 flex flex-col items-center justify-between">
            <div className="border-2 border-slate-500 w-full h-1/2 flex items-center justify-center">
              <span className="text-chocolate text-xl text-slate-200 h-48 font-semibold">DHU%</span>
            </div>
            <div className="border-2 border-slate-500 w-full h-1/2 mt-3 flex items-center justify-center">
              <span className="text-chocolate text-xl text-slate-200 h-48 font-semibold">Defective%</span>
            </div>
          </div>
        </div>
      </header>
    </section>
  );
};

export default TVDashboard2;
