from django.views import View
from django.shortcuts import redirect, render
from django.contrib import messages
from IntelliSync_db.models import FirstLevelMaster, CommonMaster
from Payroll_db.models import DepartmentMaster
from App_db.models import TnaTemplateMt, TnaTemplateDt, TnaEntryMt, TnaEntryDt
from ERP_db.models import Expohead, Expolot
from IS_Nexus.functions.shortcuts import execute_sql, execute_sql_one, formate_date, get_next_number
from django.http import JsonResponse, HttpResponse
from django.db import connections
from IS_Nexus.functions.data_conversion import queryset_to_json, queryset_to_dict
from datetime import datetime
from django.shortcuts import get_object_or_404

class TnaEntryView(View):
    def get(self, request):
        flag = request.GET.get("flag")
        
        if flag:
            if flag == 'get_template_by_order': 
                buyer_code = request.GET.get('buyer_code')
                lead_time = request.GET.get('lead_time')
                sql = f"""
                         SELECT id,template_name FROM tna_template_mt WHERE buyer_code = '{buyer_code}' and '{lead_time}' between days_from and days_to  and status = 'approved'
                    """ 
                style_data = execute_sql('default', sql)
                return JsonResponse(style_data, safe=False) 

            elif flag == 'get_style_by_buyer':
                buyer_code = request.GET.get('buyer_list')
                sql = f"""
                        SELECT distinct t1.styleno from ExpoLotDet t1 join ExpoHead t2 on t1.ourref = t2.ourref 
                        join party t4 on t4.party_code = t2.buyer where t4.party_code = '{buyer_code}' 
                        and (t2.ClosedDate is Null or t2.ClosedDate = '');
                    """
                style_data = execute_sql('erp_db', sql)
                return JsonResponse(style_data, safe=False) 
                        
            elif flag == 'get_order_by_style_and_buyer':
                style_no = request.GET.get("style_list")
                buyer_code = request.GET.get("buyer_code")
                sql = f"""
                            SELECT distinct t1.ourref from ExpoLotDet t1 
                            join ExpoHead t2 on t1.ourref = t2.ourref 
                            join party t4 on t4.party_code = t2.buyer 
                            where t4.party_code = '{buyer_code}' and t1.styleno = '{style_no}' 
                            and (t2.ClosedDate is Null or t2.ClosedDate = '');
                        """
                response_data = execute_sql('erp_db', sql)
                return JsonResponse(response_data, safe=False)
            
            elif flag == 'get_order_by_order_&_delv_date':
                order_no = request.GET.get('order_no')

                sql = f""" select t1.delvdate, t2.orderdate from ExpoLot t1
                            join ExpoHead t2 on t1.ourref = t2.ourref
                            where t1.ourref = '{order_no}';
                        """
                response_data = execute_sql_one('erp_db', sql)

                if response_data:
                    delv_date = response_data['delvdate'].strftime('%Y-%m-%d')
                    ord_date = response_data['orderdate'].strftime('%Y-%m-%d')
                    response_data = {
                        "delvdate" : delv_date,
                        "orderdate" : ord_date
                    }
                    return JsonResponse(response_data, safe=False)
                else:
                    return HttpResponse(False)
            
            elif flag == 'get_template_data':
                tna_template_id = request.GET.get('tid')

                try:
                    template_data=TnaTemplateDt.objects.using("default").filter(tna_mt__id=tna_template_id, is_active=True)

                    if template_data.exists():
                        data=[]
                        for item in template_data:
                            tmp={
                                'id': item.id,
                                'activity_name':item.activity_name.name,
                                'activity_name_id': item.activity_name.id,
                                'days_after_before':item.days_after_before,
                                'base_activity':item.base_activity.name if item.base_activity else '',
                                'base_activity_id':item.base_activity.id if item.base_activity else '',
                                'days_req':item.days_req,
                                'running_days':item.running_days,
                                'days_action':item.days_action,
                                'activity_group':item.activity_group.name,
                                'activity_group_id':item.activity_group.id,
                                'activity_type': item.activity_type
                            }
                            data.append(tmp)
                        return JsonResponse(data, safe=False)
                    
                    else:
                        return JsonResponse({'error': 'No activities found for the specified template'}, status=404)
            
                except TnaTemplateDt.DoesNotExist:
                    return JsonResponse({'error': 'Template not found'}, status=404)
  
        else:
            sql      = "SELECT distinct t2.party_code, t2.party_name from ExpoHead t1 join party t2 on t1.buyer = t2.party_code"
            buyer    = execute_sql('erp_db', sql)
            tna_template = TnaTemplateMt.objects.filter(is_active=True).values('id', 'template_name')
            
            context = {
                "buyer"        : buyer,
                "tna_template" :  tna_template
            }
            return render(request, 'T&A_Entry.html', context)

        

    def post(self, request):
        def parse_date(date_str):
            return datetime.strptime(date_str, '%d-%m-%Y').strftime('%Y-%m-%d')
        
        buyer_code      = request.POST.get('buyer')
        style           = request.POST.get('style')
        ref_no          = request.POST.get('ref_no')
        order_date      = request.POST.get('order_date')
        delivery_date   = request.POST.get('delivery_date')
        pcd_date        = request.POST.get('pcd_date')
        lead_time       = request.POST.get('lead_time')
        tna_template    = request.POST.get('tna_template')
        tna_entry_date  = request.POST.get('tna_entry_date')

        tna_template2 = TnaTemplateMt.objects.get(id=tna_template)

        tna_entry_no = get_next_number(TnaEntryMt, 'TNA')

        sql = f"SELECT party_name from party where party_code = '{buyer_code}'"
        buyer = execute_sql('erp_db', sql)
        buyer_name = buyer[0]['party_name']
        tna_entry_mt = TnaEntryMt.objects.create(
            tna_entry_no      = tna_entry_no,
            buyer_name        = buyer_name,
            buyer_code        = buyer_code,
            style             = style,
            ref_no            = ref_no,
            order_date        = order_date,
            delivery_date     = delivery_date,
            pcd_date          = pcd_date,
            lead_time         = lead_time,
            tna_template      = tna_template2,
            tna_entry_date    = tna_entry_date,
        )
        print('Done')

        activity             = request.POST.getlist('activity_name_id')
        base_activity        = request.POST.getlist('base_activity_id')
        days_req             = request.POST.getlist('days_req')
        days_after_before    = request.POST.getlist('days_after_before')
        running_days         = request.POST.getlist('running_days')
        days_action          = request.POST.getlist('days_action')
        plan_date_start      = request.POST.getlist('plan_date_start')
        plan_date_end        = request.POST.getlist('plan_date_end')
        plan_week_day        = request.POST.getlist('plan_week_day')
        res_person           = request.POST.getlist('res_person')
        res_department       = request.POST.getlist('activity_group_id')
        remark               = request.POST.getlist('remark')
        activity_type        = request.POST.getlist('activity_type')

    
        for i in range(len(activity)):

            activity_name = get_object_or_404(FirstLevelMaster, id=activity[i])
            base_activity_name = get_object_or_404(FirstLevelMaster, id=base_activity[i]) if base_activity[i] else None
            res_department_name = get_object_or_404(CommonMaster, id=res_department[i])

            TnaEntryDt.objects.create(
                tna_mt            = tna_entry_mt,
                activity          = activity_name,
                base_activity     = base_activity_name,
                days_req          = days_req[i],
                days_before_after = days_after_before[i],
                running_days      = running_days[i],
                days_action       = days_action[i],
                plan_date_start   = parse_date(plan_date_start[i]),
                plan_date_end     = parse_date(plan_date_end[i]),
                plan_week_day     = plan_week_day[i],
                res_person        = res_person[i],
                res_department    = res_department_name,
                remark            = remark[i],
                activity_type     = activity_type[i],
            )
        messages.success(request, "Success! The entry has been created.")
        return redirect ('T&A_Entry_History_page')

