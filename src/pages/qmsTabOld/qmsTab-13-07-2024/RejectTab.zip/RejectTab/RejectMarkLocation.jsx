import { useEffect, useRef, useState } from 'react';
import { useSelector ,useDispatch } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { addRejectBackImageCord,addRejectFrontImageCord,resetRejectOperations ,addRejectOperation } from '../../../utils/slice/RejectMasterSlice';
import { toast } from 'react-toastify';
import DjangoConfig from '../../../config/Config';
import axios from 'axios';

const RejectMarkLocation = () => {
    const frontCanvasRef = useRef(null);
    const backCanvasRef = useRef(null);
    const navigate =  useNavigate()
    const dispatch = useDispatch()
    const operations = useSelector(state => state.rejectMaster.operations);
    const size = useSelector(state => state.rejectMaster.size)
    const [operation ,setOperation] = useState({})
    const sewingPlanData = useSelector(state => state.sewingInput.rowData)
    const [dataSilhouettes,setDataSilhouettes] = useState([])



    if (sewingPlanData === null) {
        navigate('/end-line-login');
    }
    console.log(sewingPlanData)
    
useEffect(()=>{
    const fetchSilhouettesData =()=>{
        const userData = {
            buyer: sewingPlanData.buyer,
            styleno: sewingPlanData.styleno ,
        };
        const queryParams = new URLSearchParams(userData).toString();
        axios.get(`${DjangoConfig.apiUrl}/rtqm/style_silhouettes/?${queryParams}`, {
            headers: {
                'Content-Type': 'application/json',
            },
        }).then((response)=>{

            setDataSilhouettes(response.data)
           

            console.log("data ki pehchan karna hai", response.data);


        })
    }
    fetchSilhouettesData()
},[])

   
if (dataSilhouettes > 0) {
    console.log("Buyer:", dataSilhouettes.fields.buyer);
  } else {
    console.log('No data found');
  }




    const loadStoredData = () => {
        // const storedData = JSON.parse(localStorage.getItem('data')) || [];
        const operationData = JSON.parse(localStorage.getItem('userData') || [])
        setOperation(operationData)
        // setStoredData(storedData);
        // console.log(storedData)
      };


    const [clickedCoordinates, setClickedCoordinates] = useState([]);

    useEffect(() => {
        loadStoredData()
        // Function to draw red spots on the canvas
        const drawRedSpots = (ctx, coordinates) => {
            coordinates.forEach(coord => {
                ctx.beginPath();
                ctx.arc(coord.x, coord.y, 5, 0, 2 * Math.PI);
                ctx.fillStyle = 'red';
                ctx.fill();
            });
        };

        const frontCanvas = frontCanvasRef.current;
        const frontCtx = frontCanvas.getContext('2d');

        const backCanvas = backCanvasRef.current;
        const backCtx = backCanvas.getContext('2d');

        // Clear previous content if needed
        // frontCtx.clearRect(0, 0, frontCanvas.width, frontCanvas.height);
        // backCtx.clearRect(0, 0, backCanvas.width, backCanvas.height);

        // Retrieve images from local storage
        const frontImageUrl = localStorage.getItem('frontSketchImageUrl');
        const backImageUrl = localStorage.getItem('backSketchImageUrl');

        const drawFrontImage = () => {
            if (frontImageUrl) {
                const frontImage = new Image();
                frontImage.onload = () => {
                    frontCtx.drawImage(frontImage, 0, 0, frontCanvas.width, frontCanvas.height);
                    // Draw existing red spots
                    drawRedSpots(frontCtx, clickedCoordinates.filter(coord => coord.canvas === 'front'));
                };
                frontImage.src = frontImageUrl;
            }
        };

        const drawBackImage = () => {
            if (backImageUrl) {
                const backImage = new Image();
                backImage.onload = () => {
                    backCtx.drawImage(backImage, 0, 0, backCanvas.width, backCanvas.height);
                    // Draw existing red spots
                    drawRedSpots(backCtx, clickedCoordinates.filter(coord => coord.canvas === 'back'));
                };
                backImage.src = backImageUrl;
            }
        };

        drawFrontImage();
        drawBackImage();

        // Handle click events on the front canvas
        const handleFrontClick = (event) => {
            const rect = frontCanvas.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            // Log the coordinates relative to the front image
            console.log(`Front Image Clicked at (${x}, ${y})`);

            // Draw a red spot at the clicked location on front canvas
            drawRedSpot(frontCtx, x, y);

            // Save clicked coordinates to state
            const newCoordinates = [...clickedCoordinates, { x, y, canvas: 'front' }];
            setClickedCoordinates(newCoordinates);
        };

        frontCanvas.addEventListener('click', handleFrontClick);

        // Handle click events on the back canvas
        const handleBackClick = (event) => {
            const rect = backCanvas.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            // Log the coordinates relative to the back image
            console.log(`Back Image Clicked at (${x}, ${y})`);

            // Draw a red spot at the clicked location on back canvas
            drawRedSpot(backCtx, x, y);

            // Save clicked coordinates to state
            const newCoordinates = [...clickedCoordinates, { x, y, canvas: 'back' }];
            setClickedCoordinates(newCoordinates);
        };

        backCanvas.addEventListener('click', handleBackClick);

        // Clean up event listeners on component unmount
        return () => {
            frontCanvas.removeEventListener('click', handleFrontClick);
            backCanvas.removeEventListener('click', handleBackClick);
        };
    }, [clickedCoordinates]);

    // Function to draw a red spot (circle) at given coordinates on the canvas
    const drawRedSpot = (ctx, x, y) => {
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, 2 * Math.PI);
        ctx.fillStyle = 'red';
        ctx.fill();
    };

    const saveCoordinates = () => {
        localStorage.setItem('clickedCoordinates', JSON.stringify(clickedCoordinates));
    
        const frontCoordinates = clickedCoordinates.filter(coord => coord.canvas === 'front');
        const backCoordinates = clickedCoordinates.filter(coord => coord.canvas === 'back');
    
        if (operation.id) {
            if (frontCoordinates.length > 0) {
                dispatch(addRejectFrontImageCord({ id: operation.id, frontCoordinates }));
            }
            if (backCoordinates.length > 0) {
                dispatch(addRejectBackImageCord({ id: operation.id, backCoordinates }));
            }
        } else {
            alert("Operation ID not found. Please select an operation first.");
        }
    
        setClickedCoordinates([]);
    };

    // const clearCoordinatesById = () => {
    //     if (operation.id) {
    //         dispatch(clearCoordinates(operation.id));
    //     } else {
    //         alert("Operation ID not found. Please select an operation first.");
    //     }
    // };
    
    console.log(operations)

    const saveAddMore = () =>{
        saveCoordinates();
        navigate("/qms-tab/reject-operation-master");
    }


    // Function to clear coordinates from localStorage and remove red spots
    const clearCoordinates = () => {
        localStorage.removeItem('clickedCoordinates');
        setClickedCoordinates([]);
        const frontCanvas = frontCanvasRef.current;
        const backCanvas = backCanvasRef.current;
        const frontCtx = frontCanvas.getContext('2d');
        const backCtx = backCanvas.getContext('2d');
        frontCtx.clearRect(0, 0, frontCanvas.width, frontCanvas.height);
        backCtx.clearRect(0, 0, backCanvas.width, backCanvas.height);
    };




    const handleSubmit = async (event) => {
        saveCoordinates()
        event.preventDefault();
        let rejectq = localStorage.getItem('totalRejectQuantity');
        let totalRejectQuantity = rejectq ? JSON.parse(rejectq) : 0; 
        totalRejectQuantity++; 
        localStorage.setItem('totalRejectQuantity', JSON.stringify(totalRejectQuantity));
        navigate('/qms-tab/qc-section')
        handelresetRejectOperations()
        console.log(totalRejectQuantity);
        
        // const formData = {
        // buyer: 'Example Buyer',
        // ourref: 'Example Ref',
        // style: 'Example Style',
        // color: 'Example Color',
        // size: size,
        // defect_operation: [operations],
        // created_by: 'Example User'
        // };
        // console.log("Data for backend",formData)
        // // handelresetRejectOperations()
        // try {
        // const response = await fetch(`${DjangoConfig.apiUrl}/defect-operation-data/`, {
        //     method: 'POST',
        //     headers: {
        //     'Content-Type': 'application/json',
        //     },
        //     body: JSON.stringify(formData),
        // });
        // if (response.ok) {
        //     toast.success('DefectOperationData created successfully!');

           
        // } else {
        //     toast.error('Failed to create DefectOperationData.');

            
        // }
        // } catch (error) {
        // console.error('Error:', error);
        // toast.error('Failed to create DefectOperationData.');
        // }
    };
    const handelresetRejectOperations = () => {
        dispatch(resetRejectOperations());
      };

    return (

        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
            <h1 className="text-3xl font-bold mb-8">{operation.name}</h1>
            <div className="flex flex-col md:flex-row md:space-x-4 w-full justify-center max-w-screen-lg">
                <canvas ref={frontCanvasRef} width={300} height={400} className="border border-gray-400 mb-4 md:mb-0"></canvas>
                <canvas ref={backCanvasRef} width={300} height={400} className="border border-gray-400"></canvas>
            </div>
            <div className="mt-4 space-y-4 md:space-y-0 md:space-x-4">
                <button onClick={handleSubmit} className="w-full md:w-auto px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none">
                    Save
                </button>
                <button onClick={clearCoordinates} className="w-full md:w-auto px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 focus:outline-none">
                    Reset
                </button>
                <button onClick={saveAddMore} className="w-full md:w-auto px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 focus:outline-none">
                    Add More Operation
                </button>
            </div>
        </div>

    );
};

export default RejectMarkLocation;
