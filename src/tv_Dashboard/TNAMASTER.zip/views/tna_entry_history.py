from django.views import View
from django.shortcuts import redirect, render
from django.contrib import messages
from App_db.models import TnaEntryMt 


class TnaEntryHistoryView(View):
    def get(self, request):
          template_data = TnaEntryMt.objects.all()

          context = {
               'template_data': template_data,
          }

          return render(request, 'T&A_Entry_History.html', context)
