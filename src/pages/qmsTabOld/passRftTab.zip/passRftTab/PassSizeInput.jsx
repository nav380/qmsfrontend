import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addOrder,resetProduct,decrementQuantity  } from '../../../utils/slice/LineMasterSlice';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
const PassSizeInput = () => {
    const dispatch = useDispatch();
    const [quantity, setQuantity] = useState(0);
    const [selectedSize, setSelectedSize] = useState('');
    const orderItems = useSelector((state) => state.order.items);
    const sewingPlanData = useSelector(state => state.sewingInput.rowData);

    const navigate = useNavigate()
    
    const getQuantityForSize = (size) => {
        const item = orderItems.find(item => item.size === size);
        return item ? item.quantity : 0;

    };
    let limitedQuantity = sewingPlanData.quantity
    let totalQuantity = 0
    orderItems.forEach(item => {
        totalQuantity += item.quantity;
    });

    const handleSizeSelection = (size) => {
        if(limitedQuantity<=totalQuantity){
            toast.error("Reach Limit")
        }
        else{
            setQuantity(quantity + 1)
            setSelectedSize(size);
            console.log(selectedSize)
            saveOrder(1)
        }
    };

    const saveOrder = (quantityToSave) => {
        if (selectedSize && quantityToSave > 0) {
            dispatch(addOrder({ size: selectedSize, quantity: quantityToSave }));
        }
        if (quantityToSave < 0) {
            dispatch(addOrder({ size: selectedSize, quantity: -1 }));
        }
    };

    const handleClearStore = () => {
        dispatch(resetProduct());
    };


    const handelSave=()=>{
        navigate('/qms-tab/qc-section')
    }

    return (
        <div className="flex flex-col w-full border rounded-md p-4 m-2">
            <div className="flex justify-evenly">
                <div className="border-2 w-full items-center pb-2">
                    <p className="text-sm font-medium">Buyer</p>
                    <p className="text-sm"> {sewingPlanData.buyer} </p>
                </div>
                <div className="border-2 w-full items-center pb-2">
                    <p className="text-sm font-medium">Style</p>
                    <p className="text-sm">{sewingPlanData.styleno} </p>
                </div>
               
                <div className="border-2 w-full items-center pb-2">
                    <p className="text-sm font-medium">Color</p>
                    <p className="text-sm">{sewingPlanData.color} </p>
                </div>
                <div className="border-2 w-full items-center pb-2">
                    <p className="text-sm font-medium">Quantity</p>
                    <p className="text-sm">{sewingPlanData.quantity} </p>
                </div>
            </div>
            
            <div className="flex justify-normal w-full h-72 black-border-1">
                <div className="w-full">
                    <div className='flex flex-wrap mt-1 bg-slate-500 justify-between'>
                        <div className='flex flex-wrap w-56  justify-around'>
                            <p >Total Add Product : </p>
                            <badge>{totalQuantity}</badge> 
                        </div>
                        <div>
                            <button className='btn  btn-primary w-24 float-end' onClick={handleClearStore}> clear </button>
                        </div>

                        
                    </div>
                    <div className="gap-2">
                        <div className="flex flex-wrap justify-around">
                            <div className="w-1/5 bg-blue-500 p-4 m-2 ">
                            <p>{getQuantityForSize('AAA')}</p>
                                <button
                                    className="btn btn-primary w-full "
                                    onClick={() => handleSizeSelection('AAA')}>
                                    AAA
                                </button> 
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('BBB')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'BBB' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('BBB')}>
                                    BBB
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('XXS')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'XXS' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('XXS')}>
                                    XXS
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('XS')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'XS' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('XS')}>
                                    XS
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('S')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'S' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('S')}>
                                    S
                                </button>
                            </div>
                            
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('M')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'M' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('M')}>
                                    M
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('L')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'L' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('L')}>
                                    L
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('XL')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'XL' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('XL')}>
                                    XL
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('XXL')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'XXL' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('XXL')}>
                                    XXL
                                </button>
                            </div>
                            <div className="w-1/5 bg-blue-500 p-4 m-2">
                                <p>{getQuantityForSize('XXXL')}</p>

                                <button
                                    className={`btn btn-primary w-full ${selectedSize === 'XXXL' ? 'bg-blue-900 text-white' : 'bg-blue-400 text-white'}`}
                                    onClick={() => handleSizeSelection('XXXL')}>
                                    XXXL
                                </button>
                            </div>
                        
                        </div>
                        
                    </div>
                    <button className="px-4 py-2 bg-blue-900 w-28 float-end text-white rounded hover:bg-blue-600 mr-2" onClick={handelSave}>
                       Done
                    </button>
                </div>
            </div>
        </div>

    );
};

export default PassSizeInput;

