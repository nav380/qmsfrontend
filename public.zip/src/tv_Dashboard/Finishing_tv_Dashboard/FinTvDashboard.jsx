

import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import TvDashboard1 from "./FinTvDashboard1";
import TvDashboard2 from "./FinTvDashboard2";
import TvDashboard3 from "./FinTvDashboard3";

const FinTvDashboard = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { line_id } = useParams();
  const {process_id} = useParams();
  const {section_id} = useParams();
  console.log('Line ID in TvDashboard:', line_id);

  const dashboards = [<TvDashboard1 />, <TvDashboard2 line_id={line_id} />, <TvDashboard3 />];

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
    }, 30000); // 10 seconds

    return () => clearInterval(intervalId);
  }, []);

  const handlePrev = () => {
    setCurrentIndex(prevIndex => (prevIndex - 1 + dashboards.length) % dashboards.length);
  };

  const handleNext = () => {
    setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <div className="w-full h-full">
        {dashboards[currentIndex]}
      </div>
      {/* <button 
        className="absolute bottom-1 left-4 transform -translate-y-1/2 bg-transparent text-white border-2 border-white px-4 py-2 rounded-full focus:outline-none hover:bg-gray-700"
        onClick={handlePrev}
      >
        ←
      </button> */}
      <button 
        className="absolute top-[95px] right-4 transform -translate-y-1/2 bg-transparent text-white border-2 border-white px-4 py-2 rounded-full focus:outline-none hover:bg-gray-700"
        onClick={handleNext}
      >
        →
      </button>
    </div>
  );
};

export default FinTvDashboard;
