import { useState, useEffect } from 'react';
import Select from 'react-select';
import makeAnimated from 'react-select/animated';
import axios from "axios";
import DjangoConfig from "../../config/Config";
import { toast } from "react-toastify";
import "react-datepicker/dist/react-datepicker.css";
import 'flatpickr/dist/themes/material_green.css';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';

import TextField from '@mui/material/TextField';
import dayjs from 'dayjs';


// {   npm install @mui/x-date-pickers
// Install date library (if not already installed)
// npm install dayjs          }

const animatedComponents = makeAnimated();

const CuttingDetailEntry = () => {
    const [startDate, setStartDate] = useState(dayjs());
    console.log('startDate==========>', startDate)
    const [selectedSizes, setSelectedSizes] = useState([{ label: "Select a size", value: "" }]);
    const [selectedRatios, setSelectedRatios] = useState([{ label: "Select a ratio", value: "" }]);
    const [selectedDeliveryDates, setSelectedDeliveryDates] = useState([]);
    const [plies, setPlies] = useState("");
    const [fabricDetail, setFabricDetail] = useState(null);
    const [fabricData, setFabricData] = useState([]);
    const [totalCutPcs, setTotalCutPcs] = useState(0);
    const [sizeWiseBreakup, setSizeWiseBreakup] = useState([]);
    const [startDateTime, setStartDateTime] = useState("");

    const sizeOptions = [
        { label: "XL", value: "XL" },
        { label: "XS", value: "XS" },
        { label: "XXL", value: "XXL" },
        { label: "L", value: "L" },
        { label: "M", value: "M" },
        { label: "S", value: "S" }
    ];

    const ratioOptions = [
        { label: "1", value: 1 },
        { label: "2", value: 2 },
        { label: "3", value: 3 },
        { label: "4", value: 4 },
        { label: "5", value: 5 },
        { label: "6", value: 6 }
    ];

    const deliveryDateOptions = [
        { label: "2024-08-15", value: "2024-08-15" },
        { label: "2024-08-20", value: "2024-08-20" },
        { label: "2024-08-25", value: "2024-08-25" },
        { label: "2024-08-30", value: "2024-08-30" }
    ];

    const calculateTotalCutPcs = () => {
        const totalRatio = selectedRatios.reduce((sum, item) => sum + (item.value || 0), 0);
        const totalCut = (plies || 0) * totalRatio;
        setTotalCutPcs(isNaN(totalCut) ? 0 : totalCut);
    };

    const calculateSizeBreakup = () => {
        const sizeBreakup = selectedSizes.map((size, index) => {
            const ratioValue = selectedRatios[index] ? selectedRatios[index].value : 0;
            return {
                size: size.label,
                quantity: (plies || 0) * ratioValue
            };
        });
        setSizeWiseBreakup(sizeBreakup);
    };

    const handleFabricDetailChange = (selectedOption) => {
        setFabricDetail(selectedOption);
    };

    const handleSizeChange = (selectedOption) => {
        if (selectedOption && !selectedSizes.some(size => size.value === selectedOption.value)) {
            setSelectedSizes((prevSelectedSizes) => {
                const updatedSizes = prevSelectedSizes.filter(size => size.value !== "");
                return [...updatedSizes, selectedOption];
            });
        }
    };

    const handleRatioChange = (selectedOption) => {
        setSelectedRatios((prevSelectedRatios) => {
            const updatedRatios = prevSelectedRatios.filter(ratio => ratio.value !== "");
            return [...updatedRatios, selectedOption];
        });
    };

    const handleDeliveryDateChange = (selectedOption) => {
        if (selectedOption && !selectedDeliveryDates.some(date => date.value === selectedOption.value)) {
            setSelectedDeliveryDates((prevSelectedDeliveryDates) => [...prevSelectedDeliveryDates, selectedOption]);
        }
    };

    const removeSize = (index) => {
        setSelectedSizes((prevSelectedSizes) => prevSelectedSizes.filter((_, i) => i !== index));
        setSelectedRatios((prevSelectedRatios) => prevSelectedRatios.filter((_, i) => i !== index));
    };

    const removeRatio = (index) => {
        setSelectedRatios((prevSelectedRatios) => prevSelectedRatios.filter((_, i) => i !== index));
    };

    const removeDeliveryDate = (index) => {
        setSelectedDeliveryDates((prevSelectedDeliveryDates) => prevSelectedDeliveryDates.filter((_, i) => i !== index));
    };

    const validateForm = () => {
        if (selectedSizes.length !== selectedRatios.length) {
            toast.error("Size and ratio selections must have the same length.");
            return false;
        }
        return true;
    };

    const savecuttingData_dt = (event) => {
        event.preventDefault();
        if (!validateForm()) {
            return;
        }
        const sendingData = {
            'sizelist': selectedSizes,
            'ratiolist': selectedRatios,
            'pliesquantity': plies,
            'fabricDetail': fabricDetail,
            'totalCutPcs': totalCutPcs,
            'cutpcsquantityBySize': sizeWiseBreakup,
            'deliveryDates': selectedDeliveryDates
        };
        console.log("Sending form data:", sendingData);
        const url = `${DjangoConfig.apiUrl}/rtqm/excel_data_show_view/`;
        axios.post(url, sendingData)
            .then((res) => {
                toast.success("Data saved successfully.");
            })
            .catch((e) => {
                toast.error("Error saving data.");
            });
    };

    useEffect(() => {
        calculateTotalCutPcs();
        calculateSizeBreakup();
    }, [plies, selectedRatios, selectedSizes]);

    // Filter out selected sizes from the options
    const availableSizeOptions = sizeOptions.filter(option =>
        !selectedSizes.some(selected => selected.value === option.value)
    );

    // Filter out selected delivery dates from the options
    const availableDeliveryDateOptions = deliveryDateOptions.filter(option =>
        !selectedDeliveryDates.some(selected => selected.value === option.value)
    );

    return (
        <div className="p-14">
            <form onSubmit={savecuttingData_dt} className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">Select Sizes</label>
                    <div className="flex flex-wrap mb-2">
                        {(selectedSizes.length > 0) ? (selectedSizes.map((size, index) => (
                            <div key={index} className="inline-block bg-gray-200 rounded px-2 py-1 m-1 flex items-center">
                                {size.label}
                                <button
                                    type="button"
                                    className="ml-2 text-red-500"
                                    onClick={() => removeSize(index)}
                                >
                                    &times;
                                </button>
                            </div>
                        ))) : (<div className='bg-gray-200 rounded px-2 py-1 m-1 flex items-center'>
                            Select a size <button type="button" className="ml-2 text-red-500"> &times;
                            </button></div>)}
                    </div>
                    <Select
                        closeMenuOnSelect={false}
                        components={animatedComponents}
                        options={availableSizeOptions}
                        onChange={handleSizeChange}
                        className="border border-gray-300 rounded-md"
                        placeholder="Select Sizes"
                        styles={{
                            control: (provided) => ({
                                ...provided,
                                borderColor: '#d1d5db',
                                boxShadow: 'none',
                                width: '100%',
                                '&:hover': {
                                    borderColor: '#d1d5db',
                                },
                            }),
                        }}
                    />
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">Ratio</label>
                    <div className="flex flex-wrap mb-2">
                        {(selectedRatios.length > 0) ? (selectedRatios.map((ratio, index) => (
                            <div key={index} className="inline-block bg-gray-200 rounded px-2 py-1 m-1 flex items-center">
                                {ratio.label}
                                <button
                                    type="button"
                                    className="ml-2 text-red-500"
                                    onClick={() => removeRatio(index)}
                                >
                                    &times;
                                </button>
                            </div>
                        ))) : (<div className='bg-gray-200 rounded px-2 py-1 m-1 flex items-center'>
                            Select a ratio <button type="button" className="ml-2 text-red-500"> &times;
                            </button></div>)}
                    </div>
                    <Select
                        closeMenuOnSelect={false}
                        components={animatedComponents}
                        options={ratioOptions}
                        onChange={handleRatioChange}
                        className="border border-gray-300 rounded-md"
                        placeholder="Select Ratios"
                        styles={{
                            control: (provided) => ({
                                ...provided,
                                borderColor: '#d1d5db',
                                boxShadow: 'none',
                                width: '100%',
                                '&:hover': {
                                    borderColor: '#d1d5db',
                                },
                            }),
                        }}
                    />
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">Plies</label>
                    <input
                        type="number"
                        className="border border-gray-300 w-full rounded-md p-2 pl-3"
                        value={plies}
                        onChange={(e) => setPlies(Number(e.target.value) || "")}
                        onFocus={(e) => e.target.value === "0" && setPlies("")}
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="fabric_detail" className="block text-sm font-medium mb-2">Fabric Detail</label>
                    <Select
                        options={fabricData}
                        value={fabricDetail}
                        onChange={handleFabricDetailChange}
                        name="fabric_name"
                        placeholder="Fabric Detail"
                        className="border-2 w-full border-gray-400 rounded-md"
                        isSearchable
                        isClearable
                        styles={{
                            control: (provided) => ({
                                ...provided,
                                height: '40px',
                                fontSize: '12px',
                            }),
                        }}
                    />
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">No of PCS Cut</label>
                    <input
                        type="text"
                        className="border border-gray-300 w-full rounded-md p-2"
                        value={totalCutPcs}
                        readOnly
                    />
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">Size Wise Breakup</label>
                    <div className="border border-gray-300 w-full rounded-md p-2">
                        {sizeWiseBreakup.length > 0 ? (
                            <ul className="flex justify-start items-center">
                                {sizeWiseBreakup.map((item, index) => (
                                    <li key={index} className="ml-3">
                                        {item.size}: {item.quantity}
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p>No data available</p>
                        )}
                    </div>
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium mb-2">Delivery Dates</label>
                    <div className="flex flex-wrap mb-2">
                        {selectedDeliveryDates.map((date, index) => (
                            <div key={index} className="inline-block bg-gray-200 rounded px-2 py-1 m-1 flex items-center">
                                {date.label}
                                <button
                                    type="button"
                                    className="ml-2 text-red-500"
                                    onClick={() => removeDeliveryDate(index)}
                                >
                                    &times;
                                </button>
                            </div>
                        ))}
                    </div>
                    <Select
                        closeMenuOnSelect={false}
                        components={animatedComponents}
                        options={availableDeliveryDateOptions}
                        onChange={handleDeliveryDateChange}
                        className="border border-gray-300 rounded-md"
                        placeholder="Select Delivery Dates"
                        styles={{
                            control: (provided) => ({
                                ...provided,
                                borderColor: '#d1d5db',
                                boxShadow: 'none',
                                width: '100%',
                                '&:hover': {
                                    borderColor: '#d1d5db',
                                },
                            }),
                        }}
                    />
                </div>
                <div>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DemoContainer components={['DateTimePicker', 'DateTimePicker']}>
                            <DateTimePicker
                                label="Controlled picker"
                                value={startDate}
                                onChange={(newValue) => setStartDate(newValue)}
                            />
                        </DemoContainer>
                    </LocalizationProvider>
                </div>


                <div className="w-full col-span-2">
                    <button type="submit" className="btn btn-primary w-full">Submit</button>
                </div>
            </form>
        </div>
    );
};

export default CuttingDetailEntry;
