// import React, { useState, useEffect } from "react";
// import {  useNavigate, useParams } from "react-router-dom";
// import TvDashboard1 from "./TvDashboard1";
// import TvDashboard2 from "./TvDashboard2";

// const TvDashboard = () => {
//   const [tvdisplay, setTvDisplay] = useState('tvone');
//   const { line_id } = useParams();
//   console.log('Line ID in TvDashboard:', line_id);

//   useEffect(() => {
//     let displaychange;

//     if (tvdisplay === 'tvone') {
//       displaychange = setInterval(() => {
//         setTvDisplay('tvtwo');
//       }, 15000); // 15 seconds
//     } else if (tvdisplay === "tvtwo") {
//       displaychange = setInterval(() => {
//         setTvDisplay('tvone');
//       }, 15000); // 15 seconds
//     }

//     return () => clearInterval(displaychange);
//   }, [tvdisplay]);

// //   const navigateToTvDashboard2 = () => {
// //     navigate(`/tv/dashboard2/${line_id}`); // Navigate to TvDashboard2 with line_id
// //   };

//   return (
//     <>
//       {(tvdisplay === 'tvone') ? (<TvDashboard1  />) : (<TvDashboard2 line_id={line_id} />)}
//     </>
//   );
// };

// export default TvDashboard;

// import React, { useState, useEffect } from "react";
// import { useParams } from "react-router-dom";
// import TvDashboard1 from "./TvDashboard1";
// import TvDashboard2 from "./TvDashboard2";
// import TvDashboard3 from "./TvDashboard3";

// const TvDashboard = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const { line_id } = useParams();
//   console.log('Line ID in TvDashboard:', line_id);

//   const dashboards = [<TvDashboard1 />, <TvDashboard2 line_id={line_id} />, <TvDashboard3 />];

//   useEffect(() => {
//     const intervalId = setInterval(() => {
//       setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
//     }, 10000); // 10 seconds

//     return () => clearInterval(intervalId);
//   }, []);

//   return (
//     <>
//       {dashboards[currentIndex]}
//     </>
//   );
// };

// export default TvDashboard;


// import React, { useState, useEffect } from "react";
// import { useParams } from "react-router-dom";
// import TvDashboard1 from "./TvDashboard1";
// import TvDashboard2 from "./TvDashboard2";
// import TvDashboard3 from "./TvDashboard3";

// const TvDashboard = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const { line_id } = useParams();
//   console.log('Line ID in TvDashboard:', line_id);

//   const dashboards = [<TvDashboard1 />, <TvDashboard2 line_id={line_id} />, <TvDashboard3 />];

//   useEffect(() => {
//     const intervalId = setInterval(() => {
//       setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
//     }, 10000); // 10 seconds

//     return () => clearInterval(intervalId);
//   }, []);

//   const handlePrev = () => {
//     setCurrentIndex(prevIndex => (prevIndex - 1 + dashboards.length) % dashboards.length);
//   };

//   const handleNext = () => {
//     setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
//   };

//   return (
//     <div>
//       <div>{dashboards[currentIndex]}</div>
//       <button className="z-10 bg-white" onClick={handlePrev}>Left</button>
//       <button onClick={handleNext}>Right</button>
//     </div>
//   );
// };

// export default TvDashboard;


import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import TvDashboard1 from "./FinTvDashboard1";
import TvDashboard2 from "./FinTvDashboard2";
import TvDashboard3 from "./FinTvDashboard3";

const FinTvDashboard = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const { line_id } = useParams();
  const {process_id} = useParams();
  const {section_id} = useParams();
  console.log('Line ID in TvDashboard:', line_id);

  const dashboards = [<TvDashboard1 />, <TvDashboard2 line_id={line_id} />, <TvDashboard3 />];

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
    }, 90000); // 10 seconds

    return () => clearInterval(intervalId);
  }, []);

  const handlePrev = () => {
    setCurrentIndex(prevIndex => (prevIndex - 1 + dashboards.length) % dashboards.length);
  };

  const handleNext = () => {
    setCurrentIndex(prevIndex => (prevIndex + 1) % dashboards.length);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <div className="w-full h-full">
        {dashboards[currentIndex]}
      </div>
      {/* <button 
        className="absolute bottom-1 left-4 transform -translate-y-1/2 bg-transparent text-white border-2 border-white px-4 py-2 rounded-full focus:outline-none hover:bg-gray-700"
        onClick={handlePrev}
      >
        ←
      </button> */}
      <button 
        className="absolute top-[95px] right-4 transform -translate-y-1/2 bg-transparent text-white border-2 border-white px-4 py-2 rounded-full focus:outline-none hover:bg-gray-700"
        onClick={handleNext}
      >
        →
      </button>
    </div>
  );
};

export default FinTvDashboard;
