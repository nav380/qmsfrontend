import React from 'react'

function MainDashboard() {
  return (
    <div>MainDashboard</div>
  )
}

export default MainDashboard