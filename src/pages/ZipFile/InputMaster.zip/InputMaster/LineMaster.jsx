import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { Box, Button, Menu, MenuItem } from '@mui/material';
import { MaterialReactTable, createMRTColumnHelper, useMaterialReactTable } from 'material-react-table';
import Skeleton from 'react-loading-skeleton';
import { toast } from 'react-toastify';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import DjangoConfig from '../../config/Config';
import { saveRows } from '../../utils/slice/SewingInputSlice';



const LineMaster = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const userData = useSelector(state => state.user.userData);
    console.log(userData)
    const [tableData, setTableData] = useState([])

    // console.log("userData", userData)
   

    useEffect(() => {
        fetchPlaningData();

    }, [])

    const fetchPlaningData = () => {
        axios.get(`${DjangoConfig.apiUrl}/rtqm/cutting_master/`, {
            headers: {
                'Content-Type': 'application/json',
            },
        })
            .then(response => {
                const responseData = response.data.cutMtdata
                console.log(responseData)
                setTableData(responseData)
            })
            .catch(error => {
                console.error('Error fetching filtered data:', error);
            });
    };

    const handleExportRows = (rows) => {
                try {
                    if (rows && rows.length > 0 && rows[0].original) {
                        const rowData = rows[0].original;
                        console.log("rowData",rowData)
                        localStorage.setItem('cuttingData', JSON.stringify(rowData));
                        dispatch(saveRows(rowData));
                        console.log("Cutting Data",rowData)
                        navigate('/input-master/select-quantity-by-master');
                    } else {
                        console.error('Invalid rows or missing "original" property');
                    }
                } catch (error) {
                    console.error('Error saving rows:', error);
                }
            };

    const columnHelper = createMRTColumnHelper();
    const columns = [
        columnHelper.accessor((row, index) => index + 1, { header: 'S/N', size: 40 }),
        columnHelper.accessor('buyer_name', { header: 'Buyer', size: 20 }),
        columnHelper.accessor('style', { header: 'Style No', size: 20 }),
        columnHelper.accessor('color', { header: 'Color ', size: 20 }),
        columnHelper.accessor('totalqty', { header: 'Total Cut Qty', size: 20 }),
        columnHelper.accessor('orderqty', { header: 'OrderQuantity', size: 20 }),
        columnHelper.accessor('delvdate', { header: 'Delivery Date', size: 20 }),
    ];



    const table = useMaterialReactTable({
        columns,
        data: tableData,
        // state: {
        //   isLoading:  isLoading ? <Skeleton count={5} /> : null,

        // },
        enableRowSelection: true,
        columnFilterDisplayMode: 'popover',
        paginationDisplayMode: 'pages',
        positionToolbarAlertBanner: 'bottom',
        enableMultiRowSelection:false,
        renderTopToolbarCustomActions: ({ table }) => (
            <Box
                sx={{
                    display: 'flex',
                    gap: '10px',
                    padding: '4px',
                    flexWrap: 'wrap',
                    style: { fontSize: '5px' },
                }}
            >

               
                <Button
                    disabled={
                        !table.getIsSomeRowsSelected() && !table.getIsAllRowsSelected()
                    }
                    //only export selected rows
                    onClick={() => handleExportRows(table.getSelectedRowModel().rows)}
                    startIcon={<FileDownloadIcon />}
                    >
                        Save Data
                </Button>
            </Box>
        ),
    });

    return (
        <div>

            <div className='mt-2'>
                <MaterialReactTable table={table} />
            </div>

        </div>
    );
};

export default LineMaster;
