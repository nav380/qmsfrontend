import axios from 'axios';
import React, { useEffect, useState } from 'react';
import favicon from "./favicon.ico"
import DjangoConfig from '../config/Config';


const TvDashboard1 = () => {
  const [time, setTime] = useState('');
  const [data, setDate] = useState([])
  const [loading, setLoading] = useState(true);



  const updateTime = () => {
    const now = new Date();
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; 
    const hoursStr = hours.toString().padStart(2, '0');
    setTime(`${hoursStr}:${minutes}:${seconds} ${ampm}`);
  };
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(`${DjangoConfig.apiUrl}/rtqm/check_status/`);
        setDate(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();

    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  console.log( "indrajeet---->",data)

  return (
    <section id="dashboard" className="text-white bg-black pb-4">
      <header>
        <nav className="bg-[#070F2B] border-2 border-gray-600 w-full h-16 flex items-center">
          <div className="w-1/5 h-full flex items-center justify-center border-r border-black">
            <a className="flex items-center justify-center" href="#" style={{ cursor: 'pointer' }}>
              <img src={favicon} alt="logo" className="mr- w-10" />
              <span className="text-goldenrod text-2xl font-semibold mb-2">IntelliSYNC</span>
            </a>
          </div>
          <div className="w-3/5 h-full flex items-center justify-center border-r border-black">
            <span className="text-goldenrod text-3xl font-bold">Sewing Dashboard</span>
          </div>
          <div className="w-1/5 h-full flex items-center justify-center">
            <div id="time" className="text-goldenrod text-2xl font-bold mt-6 ml-10">{time || 'Loading time...'}</div>
          </div>
        </nav>

        <div className="bg-black border border-gray-500 w-full h-7vh flex justify-between pt-2 pb-2 items-center mt-1">
          <div className="w-1/5 h-full flex items-center justify-center border-r border-black">
            <span className="text-white text-2xl font-semibold">Line</span>
          </div>
          <div className="w-1/5 h-full flex items-center justify-center border-r border-black">
            <span className="text-white text-2xl font-semibold">Buyer</span>
          </div>
          <div className="w-1/5 h-full flex items-center justify-center border-r border-black">
            <span className="text-white text-2xl font-semibold">Style</span>
          </div>
          <div className="w-1/5 h-full flex items-center justify-center border-r border-black">
            <span className="text-white text-2xl font-semibold">Colour</span>
          </div>
          <div className="w-1/5 h-full flex items-center justify-center">
            <span className="text-white text-2xl font-semibold">Hour No</span>
          </div>
        </div>

        <div className="flex h-[79vh] w-full mt-1">
          <div className="w-1/3 h-full flex flex-col">
            <div className="border-2  border-gray-500 w-full pl-3 flex flex-col items-start justify-evenly h-[64vh]">
              <span className="text-chocolate text-white text-3xl font-semibold">Day Target</span>
              <span className="text-chocolate text-white text-3xl font-semibold">Real Time Target</span>
              
              <span className="text-chocolate text-white text-3xl font-semibold">Difference</span>
              <span className="text-chocolate text-white text-3xl font-semibold">Alter Balance&nbsp;&nbsp;:&nbsp;&nbsp;<span className='font-bold'>{data[1]?.alter_balance || 'Loading...'}</span></span>
              <span className="text-chocolate text-white text-3xl font-semibold">Actual&nbsp;&nbsp;:&nbsp;&nbsp;<span className='font-bold'>{data[0]?.actual_pass || 'Loading...'}</span></span>
            </div>
            <div className="border-2 border-gray-500 w-full h-[12vh] mt-3 flex items-center justify-center">
              <span className="text-chocolate text-white text-3xl font-semibold">WIP</span>
            </div>
          </div>

          <div className="w-[45%] h-full flex flex-col ml-3">
            <div className="flex w-full h-[65vh]">
              <div className="border-2 border-gray-500 w-1/2 h-full flex items-center justify-center">
              <div>
                <span className="text-chocolate text-whitetext-white text-3xl font-semibold">RFT%</span>
                <h2 className='font-bold text-3xl text-white pt-4'>{data[2]?.rft_percentage || 'Loading...'}</h2>
                </div>
              </div>
              <div className="border-2 border-gray-500 w-1/2 h-full ml-3 flex items-center justify-center">
                <span className="text-chocolate text-whitetext-white text-3xl font-semibold">EFF%</span>
              </div>
            </div>
            <div className="flex w-full h-[12vh] mt-3">
              <div className="border-2 border-gray-500 w-1/2 h-full flex items-center justify-center">
                <span className="text-chocolate text-whitetext-white text-3xl font-semibold">Manpower Tailor</span>
              </div>
              <div className="border-2 border-gray-500 w-1/2 h-full ml-3 flex items-center justify-center">
                <span className="text-chocolate text-white  text-3xl font-semibold">Manpower Helper</span>
              </div>
            </div>
          </div>

          <div className="w-1/5 h-full ml-3 flex flex-col">
            <div className="border-2 border-gray-500 w-full h-[39vh] flex items-center justify-center">
              <div>
              <span className="text-chocolate  text-white text-3xl font-semibold">DHU%</span>
              <h2 className='font-bold text-3xl text-white pt-4'>{data[3]?.dhu_percentage || 'Loading...'}</h2>
              </div>
            </div>
            <div className="border-2 border-gray-500 w-full h-[38vh] mt-3 flex items-center justify-center">
              <div>
              <span className="text-chocolate text-3xl text-white font-semibold">Defective%</span>
              <h2 className='font-bold text-3xl text-white'>{data[4]?.defective_percentage || 'Loading...'}</h2>
              </div>
            </div>
          </div>
        </div>
      </header>
    </section>
  );
};

export default TvDashboard1;
